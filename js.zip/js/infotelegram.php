<?php

$token = "6017472115:AAEGK2rmYbW2WlkomRJRN1_l3WnVEuDyNY4";
$tid = "6084053716";

?>